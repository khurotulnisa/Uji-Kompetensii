<?php
  include "koneksi.php";

  $id = $_GET['id_peserta'];
  $data=mysqli_query($koneksi, "select * from tb_peserta where id_peserta='$id'");
  $d = mysqli_fetch_array($data);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title> Admin Edit </title>
</head>
<body>
    <h1> EDIT DATA SERTIFIKASI   </h1>
    <hr>
    <form action="update.php" method="post">
      <div>
        <label for="id_peserta">ID Peserta</label><br>
        <input type="text" name="id_peserta" value="<?php echo $d['id_peserta'];?>" required="required">
      </div>
      <div>
        <label for="kd_skema">Kode Skema</label><br>
        <input type="text" name="nama" value="<?php echo$d['kd_skema'];?>" required="required">
      </div>
      <div>
        <label for="nm_peserta">Nama Peserta</label><br>
        <input type="text" name="nm_peserta" value="<?php echo$d['nm_peserta'];?>" required="required">
      </div>
      <div>
        <label for="jekel">JENIS KELAMIN</label><br>
        <select name="jekel" id = "jekel">
          <option value="laki-laki">LAKI-LAKI</option>
          <option value="perempuan">PEREMPUAN</option>
        </select> 
      </div>
      <div>
        <div>
        <label for="alamat">ALAMAT</label><br>
        <input type="text" name="alamat" value="<?php echo$d['alamat'];?>" required="required">
        <div>
        <label for="no_hp">No HP</label><br>
        <input type="text" name="no_hp" value="<?php echo$d['no_hp'];?>" required="required">
      </div>
      </div>
      </div>
      <input type="submit" value="SIMPAN">
      </form>         
        </label>
</body>
</html>