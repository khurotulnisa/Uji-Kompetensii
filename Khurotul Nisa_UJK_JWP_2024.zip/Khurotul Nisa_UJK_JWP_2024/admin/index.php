<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>LOGIN</title>
</head>
<body>
	<h1>LOGIN</h1>
	<hr>
	<form action="aksi_login.php" method="post">
		<label for="username">USERNAME</label> <br>
		<input type="text" name="username" placeholder="masukan username"><br>
		<label for="password">PASSWORD</label> <br>
		<input type="password" name="password">
		<input type="submit" value="LOGIN">
	</form>
</body>
</html>