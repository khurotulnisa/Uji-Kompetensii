<?php 
	$username = "admin";
	$password = "admin";

	if($username== $_POST['username'] and $password== $_POST['password']){
		header("location:data_sertifikasi.php");

	}else{
		header("location:index.php");  
	}



?>

