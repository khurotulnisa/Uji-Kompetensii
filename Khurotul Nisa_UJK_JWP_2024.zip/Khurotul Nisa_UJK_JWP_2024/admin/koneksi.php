<?php

	$koneksi = mysqli_connect("localhost","root","","db_ujk");

	if (!$koneksi) {
		# code...
		die("koneksi gagal: " . mysqli_connect_error());
	}
	
?>