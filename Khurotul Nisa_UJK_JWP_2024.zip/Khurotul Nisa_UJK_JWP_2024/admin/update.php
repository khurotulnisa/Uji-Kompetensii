<?php
$koneksi = mysqli_connect("localhost", "root", "", "db_ujk");
if (!$koneksi) {
    die("Connection failed: " . mysqli_connect_error());
}

    $id_peserta = $_POST['id_peserta'];
    $kd_skema = $_POST['kd_skema'];
    $jekel= $_POST['jekel'];
    $alamat = $_POST['alamat'];
    $no_hp = $_POST['no_hp'];

   
$update = mysqli_query($koneksi, "update tb_peserta set 
    id_peserta='$id_peserta', kd_skema='$kd_skema', jekel= '$jekel', alamat = '$alamat', no_hp='$no_hp' where id_peserta='$id_peserta'");

header("Location: data_sertifikasi.php");
?>