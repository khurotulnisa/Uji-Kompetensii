<?php 
	include 'koneksi.php';
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Data Sertifikasi</title>
	<a href="form.php" class="btn">Tambah Sertifikasi</a>
	<hr>
	<style type="text/css">
		body{
			font-family: sans-serif;
			width: 80%;
			text-align: center;
			margin: auto;
			text-decoration : none;
		}
		header {
			width: 100%;
			margin: auto;
			display: flex;
			line-height: 80px;
			position: sticky;
			top: 0;
			z-index: 1;
		}
		.wrapper {
			width: 100%;
			margin: auto;
			position: relative;
		}
		.menu {
			float: right;
		}
		ul {
			list-style-type: none;
			margin: 0;
			padding: 0;
			overflow: hidden;
		}
		ul li {
			float: left;
			display: inline;
		}
		ul li a{
			color: #F49D1A;
			font-weight: bold;
			text-align: center;
			padding: 0px 16px 0px 16px;
		}
		ul li a:hover{
			color: red;
		}

		.table1{
			font-family: sans-serif;
			border-collapse: collapse;
			width: 100%;
			margin: auto;
		}

		.table1 tr th {
			background: #35A9DB;
			color: #fff;
			text-align: center;
			padding: 20px 8px;
		}

		.table1, th, td {
			text-align: center;
			padding: 20px 8px;
			border: 1px solid lightblue;
		}

		.btn-edit {
			background: darkblue;
			padding: 10px 15px 10px 15px;
			color: #fff;
			font-family: sans-serif;
			margin: 5px 5px;
			text-decoration: none;
		}

		.btn-hapus{
			background: darkblue;
			padding: 10px 15px 10px 15px;
			color: #fff;
			font-family: sans-serif;
			margin: 5px 5px;
			text-decoration: none;
		}

		.btn {
			background: darkblue;
			padding: 10px 15px 10px 15px;
			color: #fff;
			font-family: sans-serif;
			margin: 5px 5px;
			text-decoration: none;
			float: left;
		}

		a:hover{
			color: red;
		}

		.table1 tr:hover {
			background-color: lightblue;
		}


	</style>
</head>
<body>
	<header>
	<div class="wrapper">

	<div class="menu">
		<ul>
			

			<li><a href="logout.php" onclick="return confirm('Konfirmasi logout!')">LOGOUT</a></li>
		</ul>
	</div>
	</div>
	</header>
	<br>
	<h2>DATA SERTIFIKASI </h2>
	<?php 
      if (isset($_SESSION['pesan'])) {
        ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <strong>
              <?php echo $_SESSION['pesan']; ?>
          </strong> 
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php 
        session_destroy();
            }
    ?>
	<hr>
	<table class="table1">
		<thead>
		<tr>
			<th>ID PESERTA</th>
			<th>KD SKEMA</th>
			<th>NAMA PESERTA</th>
			<th>JEKEL</th><br>
			<th>ALAMAT</th><br>
			<th>NOMOR HP</th>
			<th width="200px">ACTION</th>
		</tr>
		</thead>
		<tbody>
			<?php
			 $no = 1;
			 $data = mysqli_query($koneksi, "select * from tb_peserta");
			 while ($d=mysqli_fetch_array($data)) {
			 	# code...
			 ?>
		<tr>
			
			<td><?php echo $d['id_peserta'];?></td>
			<td><?php echo $d['kd_skema'];?></td>
			<td><?php echo $d['nm_peserta'];?></td>
			<td><?php echo $d['jekel'];?></td>
			<td><?php echo $d['alamat'];?></td>
			<td><?php echo $d['no_hp'];?></td>
			<td><a href="edit_sertifikasi.php?id_peserta=<?php echo $d['id_peserta'];?>" class="btn-edit">Edit</a> <a href="hapus.php?id_peserta=<?php echo $d['id_peserta'];?>" onclick="return confirm('Apakah akan menghapus data ini? ')" class="btn-hapus">Hapus</a></td>
	
		</tr>
	<?php } ?>
		
		</tbody>
	</table>
</body>
</html>