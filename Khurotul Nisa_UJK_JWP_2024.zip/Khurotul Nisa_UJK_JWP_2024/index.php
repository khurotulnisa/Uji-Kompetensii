<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SERTIFIKASI UJI KOMPETENSI</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container">
    <a class="navbar-brand" href="#">
      <img src="images/logo-bnsp.png" alt="Logo" width="30" height="24">
    </a>
    <a class="navbar-brand" href="#">UKOM</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="form.php">Pendaftaran</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="admin/index.php">Admin</a>
        </li>    
      </ul>
    </div>
  </div>
</nav>
<div class="container">
  <div id="carouselExample" class="carousel slide">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/gambar1.jpg" class="d-block w-100" alt="...">
    </div>
     </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>
<div class="container">
  
<footer class="container">
      <div class="container">
        <h1>Data Peserta</h1>
        <form action="" method="post">
            <div class="form-group">
                <label for="nm_peserta">Cari Peserta</label>
                <input type="text" class="form-control" id="nm_peserta" name="nm_peserta" placeholder="Masukkan nama peserta">
                <button type="submit" class="btn btn-primary">Cari</button>
            </div>
        </form>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID Peserta</th>
                    <th>Kode Skema</th>
                    <th>Nama Peserta</th>
                    <th>Jenis Kelamin</th>
                    <th>Alamat</th>
                    <th>Nomor HP</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Connect to database
                $koneksi = mysqli_connect("localhost", "root", "", "db_ujk");

                // Check connection
                if (!$koneksi) {
                    die("Connection failed: " . mysqli_connect_error());
                }

                // Query to retrieve all participant data
                $query = "SELECT * FROM tb_peserta";
                $result = mysqli_query($koneksi, $query);

                // Check if search query is submitted
                if (isset($_POST['nm_peserta'])) {
                    $nm_peserta = $_POST['nm_peserta'];
                    $query = "SELECT * FROM tb_peserta WHERE nm_peserta LIKE '%$nm_peserta%'";
                    $result = mysqli_query($koneksi, $query);
                }

                // Display participant data
                $no = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <tr>
                        <td><?= $row['id_peserta'] ?></td>
                        <td><?= $row['kd_skema'] ?></td>
                        <td><?= $row['nm_peserta'] ?></td>
                        <td><?= $row['jekel'] ?></td>
                        <td><?= $row['alamat'] ?></td>
                        <td><?= $row['no_hp'] ?></td>
                    </tr>
                    <?php
                    $no++;
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
      </ul>
    </div>

</nav>
</footer>
</body>
</html>